﻿using System;
using System.Net.Http.Json;
using System.Net.Http;
using System.Windows.Forms;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace WindowsFormsApp1
{
    public partial class AuswahlForm : Form
    {
        private static readonly HttpClient client = new HttpClient();
        
        public AuswahlForm()
        {
            InitializeComponent();
            
        }
        public AuswahlForm(telefonNotiz form1)
        {
            InitializeComponent();
            telefonNotiz = form1;

        }

        telefonNotiz telefonNotiz = new telefonNotiz();

        private async void AuswahlForm_Load(object sender, EventArgs e)
        {
            try
            {
                HttpResponseMessage response = await client.GetAsync("http://127.0.0.1:5000/api/v1/users-telNumber");
                response.EnsureSuccessStatusCode();
                string responseBody = await response.Content.ReadAsStringAsync();

                List<List<string>> lists = JsonConvert.DeserializeObject<List<List<string>>>(responseBody);

                List<string> strings = lists.SelectMany(x => x).ToList();
                dataGridView1.Columns.Add("Telefon Number", "Telefon Number");

                foreach (var item in strings)
                {
                    dataGridView1.Rows.Add(item);
                }

            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridView1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
                     
            string value = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            telefonNotiz.telefonTextBox.Text = value;
           

        }
    }
}
