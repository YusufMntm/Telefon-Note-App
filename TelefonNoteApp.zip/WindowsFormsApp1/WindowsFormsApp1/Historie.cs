﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;


namespace WindowsFormsApp1
{
    public partial class Historie : Form
    {
        public Historie()
        {
            InitializeComponent();
        }

        private async void CustomerAllKnowladge()
        {

            using (var client = new HttpClient())
            {
                //Customer Response
                var customerResponse = await client.GetAsync("http://localhost:5000/api/v1/users-customerName");
                customerResponse.EnsureSuccessStatusCode();
                string customerResponseBody = await customerResponse.Content.ReadAsStringAsync();

                List<List<string>> customerLists = JsonConvert.DeserializeObject<List<List<string>>>(customerResponseBody);

                List<string> customerStrings = customerLists.SelectMany(x => x).ToList();
                dataGridView1.Columns.Add("Customer", "Customer");


                //Kontakt Response
                var kontaktResponse = await client.GetAsync("http://localhost:5000/api/v1/users-kontakt");
                kontaktResponse.EnsureSuccessStatusCode();
                string KontaktResponseBody = await kontaktResponse.Content.ReadAsStringAsync();

                List<List<string>> kontaktLists = JsonConvert.DeserializeObject<List<List<string>>>(KontaktResponseBody);

                List<string> kontaktStrings = kontaktLists.SelectMany(x => x).ToList();
                dataGridView1.Columns.Add("Kontakt", "Kontakt");

                //Telefon Response
                var telefonResponse = await client.GetAsync("http://localhost:5000/api/v1/users-telNumber");
                telefonResponse.EnsureSuccessStatusCode();
                string telefonResponseBody = await telefonResponse.Content.ReadAsStringAsync();

                List<List<string>> telefonLists = JsonConvert.DeserializeObject<List<List<string>>>(telefonResponseBody);

                List<string> telefonStrings = telefonLists.SelectMany(x => x).ToList();
                dataGridView1.Columns.Add("Telefon", "Telefon");

                //Topic Response
                var topicResponse = await client.GetAsync("http://localhost:5000/api/v1/users-topic");
                topicResponse.EnsureSuccessStatusCode();
                string topicResponseBody = await topicResponse.Content.ReadAsStringAsync();

                List<List<string>> topicLists = JsonConvert.DeserializeObject<List<List<string>>>(topicResponseBody);

                List<string> topicStrings = topicLists.SelectMany(x => x).ToList();
                dataGridView1.Columns.Add("Topic", "Topic");

                //Note Response
                var noteResponse = await client.GetAsync("http://localhost:5000/api/v1/users-note");
                noteResponse.EnsureSuccessStatusCode();
                string noteResponseBody = await noteResponse.Content.ReadAsStringAsync();

                List<List<string>> noteLists = JsonConvert.DeserializeObject<List<List<string>>>(noteResponseBody);

                List<string> noteStrings = noteLists.SelectMany(x => x).ToList();
                dataGridView1.Columns.Add("Note", "Note");

                //File_Path Response
                var file_pathResponse = await client.GetAsync("http://localhost:5000/api/v1/users-file_path");
                file_pathResponse.EnsureSuccessStatusCode();
                string file_pathResponseBody = await file_pathResponse.Content.ReadAsStringAsync();
                
                List<List<string>> file_pathLists = JsonConvert.DeserializeObject<List<List<string>>>(file_pathResponseBody);

                List<string> file_pathStrings = file_pathLists.SelectMany(x => x).ToList();
                dataGridView1.Columns.Add("File Path", "File Path");

                for (int i = 0; i < customerStrings.Count; i++)
                {
                    dataGridView1.Rows.Add(customerStrings[i], kontaktStrings[i], telefonStrings[i], topicStrings[i], noteStrings[i], file_pathStrings[i]);
                }


            }
        }
        private void Historie_Load(object sender, EventArgs e)
        {
            CustomerAllKnowladge();
        }

        private void exortToExcel_Click(object sender, EventArgs e)
        {
            Excel.Application app = new Excel.Application(); 
            Workbook wb = app.Workbooks.Add(System.Reflection.Missing.Value);
            Worksheet ws = (Worksheet)wb.ActiveSheet;
            app.Visible = true;

            for(int i = 0; i < dataGridView1.Columns.Count; i++)
            {
                Range dataColumn = (Range)ws.Cells[1, 1];
                dataColumn.Cells[1, i + 1] = dataGridView1.Columns[i].HeaderText;
            }

            for (int i = 0; i < dataGridView1.SelectedRows.Count; i++)
            {
                for(int j = 0; j < dataGridView1.SelectedRows[i].Cells.Count; j++)
                {
                    Range dataRows = (Range)ws.Cells[i + 1, j + 1];
                    dataRows.Cells[2,1] = dataGridView1.SelectedRows[i].Cells[j].Value;
                }
            }
        }

     


     
    }
}
