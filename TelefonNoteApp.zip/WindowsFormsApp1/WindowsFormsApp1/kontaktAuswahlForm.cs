﻿using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace WindowsFormsApp1
{
    public partial class kontaktAuswahlForm : Form
    {
        public kontaktAuswahlForm()
        {
            InitializeComponent();
            
        }

        public kontaktAuswahlForm(telefonNotiz form1)
        {
            InitializeComponent();
            telefonNotiz = form1;

        }
        telefonNotiz telefonNotiz = new telefonNotiz();
        private async void CustomerKontakt()
        {
            using (var client = new HttpClient())
            {
                //Customer Response
                var customerResponse = await client.GetAsync("http://localhost:5000/api/v1/users-customerName");
                customerResponse.EnsureSuccessStatusCode();
                string customerResponseBody = await customerResponse.Content.ReadAsStringAsync();

                List<List<string>> customerLists = JsonConvert.DeserializeObject<List<List<string>>>(customerResponseBody);

                List<string> customerStrings = customerLists.SelectMany(x => x).ToList();
                dataGridView1.Columns.Add("Customer", "Customer");


                //Kontakt Response
                var kontaktResponse = await client.GetAsync("http://localhost:5000/api/v1/users-kontakt");
                kontaktResponse.EnsureSuccessStatusCode();
                string KontaktResponseBody = await kontaktResponse.Content.ReadAsStringAsync();

                List<List<string>> kontaktLists = JsonConvert.DeserializeObject<List<List<string>>>(KontaktResponseBody);

                List<string> kontaktStrings = kontaktLists.SelectMany(x => x).ToList();
                dataGridView1.Columns.Add("Kontakt", "Kontakt");
                
                for (int i = 0; i < customerStrings.Count; i++)
                {
                    dataGridView1.Rows.Add(customerStrings[i], kontaktStrings[i]);
                }

            }
        }
        
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {


        }

        private void button1_Click(object sender, System.EventArgs e)
        {
           
        }

        private void textBox1_TextChanged(object sender, System.EventArgs e)
        {

        }

        private void kontaktAuswahlForm_Load(object sender, System.EventArgs e)
        {
            CustomerKontakt();
        }

        private void dataGridView1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            telefonNotiz.firmennameTextBox.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            telefonNotiz.kontaktTextBox.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
        }
    }
}
