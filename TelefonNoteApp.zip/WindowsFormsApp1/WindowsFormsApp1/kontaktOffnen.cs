﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace WindowsFormsApp1
{
    public partial class kontaktOffnen : Form
    {
        public kontaktOffnen()
        {
            InitializeComponent();
        }

        private void kontaktOffnen_Load(object sender, EventArgs e)
        {
            CustomerKontaktTelefon();
        }

        private  async void CustomerKontaktTelefon()
        {
            
            using (var client = new HttpClient())
            {
                //Customer Response
                var customerResponse = await client.GetAsync("http://localhost:5000/api/v1/users-customerName");
                customerResponse.EnsureSuccessStatusCode();
                string customerResponseBody = await customerResponse.Content.ReadAsStringAsync();

                List<List<string>> customerLists = JsonConvert.DeserializeObject<List<List<string>>>(customerResponseBody);

                List<string> customerStrings = customerLists.SelectMany(x => x).ToList();
                dataGridView1.Columns.Add("Customer", "Customer");


                //Kontakt Response
                var kontaktResponse = await client.GetAsync("http://localhost:5000/api/v1/users-kontakt");
                kontaktResponse.EnsureSuccessStatusCode();
                string KontaktResponseBody = await kontaktResponse.Content.ReadAsStringAsync();

                List<List<string>> kontaktLists = JsonConvert.DeserializeObject<List<List<string>>>(KontaktResponseBody);

                List<string> kontaktStrings = kontaktLists.SelectMany(x => x).ToList();
                dataGridView1.Columns.Add("Kontakt", "Kontakt");

                //Telefon Response
                var telefonResponse = await client.GetAsync("http://localhost:5000/api/v1/users-telNumber");
                telefonResponse.EnsureSuccessStatusCode();
                string telefonResponseBody = await telefonResponse.Content.ReadAsStringAsync();

                List<List<string>> telefonLists = JsonConvert.DeserializeObject<List<List<string>>>(telefonResponseBody);

                List<string> telefonStrings = telefonLists.SelectMany(x => x).ToList();
                dataGridView1.Columns.Add("Telefon", "Telefon");

                for (int i = 0; i < customerStrings.Count; i++)
                {
                    dataGridView1.Rows.Add(customerStrings[i], kontaktStrings[i], telefonStrings[i]);
                }

                
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
