﻿namespace WindowsFormsApp1
{
    partial class telefonNotiz
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(telefonNotiz));
            this.firmennameLabel = new System.Windows.Forms.Label();
            this.firmennameTextBox = new System.Windows.Forms.TextBox();
            this.kontaktLabel = new System.Windows.Forms.Label();
            this.kontaktTextBox = new System.Windows.Forms.TextBox();
            this.telefonLabel = new System.Windows.Forms.Label();
            this.telefonTextBox = new System.Windows.Forms.TextBox();
            this.betreffLabel = new System.Windows.Forms.Label();
            this.betreffTextBox = new System.Windows.Forms.TextBox();
            this.notizLabel = new System.Windows.Forms.Label();
            this.notizTextBox = new System.Windows.Forms.TextBox();
            this.notizComboBox = new System.Windows.Forms.ComboBox();
            this.anhangLabel = new System.Windows.Forms.Label();
            this.filePathNameComboBox = new System.Windows.Forms.ComboBox();
            this.wiedervorlage = new System.Windows.Forms.CheckBox();
            this.screenshot = new System.Windows.Forms.Button();
            this.kontaktAuswahlButton = new System.Windows.Forms.Button();
            this.auswahlButton = new System.Windows.Forms.Button();
            this.einfügenButton = new System.Windows.Forms.Button();
            this.loadFileButton = new System.Windows.Forms.Button();
            this.speichernButton = new System.Windows.Forms.Button();
            this.kontaktOffnenButton = new System.Windows.Forms.Button();
            this.historieButton = new System.Windows.Forms.Button();
            this.druckenButton = new System.Windows.Forms.Button();
            this.funktionenButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // firmennameLabel
            // 
            this.firmennameLabel.AutoSize = true;
            this.firmennameLabel.Font = new System.Drawing.Font("Microsoft Tai Le", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firmennameLabel.Location = new System.Drawing.Point(20, 71);
            this.firmennameLabel.Name = "firmennameLabel";
            this.firmennameLabel.Size = new System.Drawing.Size(117, 23);
            this.firmennameLabel.TabIndex = 0;
            this.firmennameLabel.Text = "Firmenname :";
            this.firmennameLabel.Click += new System.EventHandler(this.firmennameLabel_Click);
            // 
            // firmennameTextBox
            // 
            this.firmennameTextBox.Location = new System.Drawing.Point(180, 74);
            this.firmennameTextBox.Name = "firmennameTextBox";
            this.firmennameTextBox.Size = new System.Drawing.Size(548, 22);
            this.firmennameTextBox.TabIndex = 1;
            this.firmennameTextBox.TextChanged += new System.EventHandler(this.firmennameTextBox_TextChanged);
            // 
            // kontaktLabel
            // 
            this.kontaktLabel.AutoSize = true;
            this.kontaktLabel.Font = new System.Drawing.Font("Microsoft Tai Le", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kontaktLabel.Location = new System.Drawing.Point(20, 109);
            this.kontaktLabel.Name = "kontaktLabel";
            this.kontaktLabel.Size = new System.Drawing.Size(80, 23);
            this.kontaktLabel.TabIndex = 2;
            this.kontaktLabel.Text = "Kontakt :";
            this.kontaktLabel.Click += new System.EventHandler(this.kontaktLabel_Click);
            // 
            // kontaktTextBox
            // 
            this.kontaktTextBox.Location = new System.Drawing.Point(180, 112);
            this.kontaktTextBox.Name = "kontaktTextBox";
            this.kontaktTextBox.Size = new System.Drawing.Size(548, 22);
            this.kontaktTextBox.TabIndex = 3;
            // 
            // telefonLabel
            // 
            this.telefonLabel.AutoSize = true;
            this.telefonLabel.Font = new System.Drawing.Font("Microsoft Tai Le", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.telefonLabel.Location = new System.Drawing.Point(20, 144);
            this.telefonLabel.Name = "telefonLabel";
            this.telefonLabel.Size = new System.Drawing.Size(77, 23);
            this.telefonLabel.TabIndex = 4;
            this.telefonLabel.Text = "Telefon :";
            // 
            // telefonTextBox
            // 
            this.telefonTextBox.Location = new System.Drawing.Point(180, 147);
            this.telefonTextBox.Name = "telefonTextBox";
            this.telefonTextBox.Size = new System.Drawing.Size(548, 22);
            this.telefonTextBox.TabIndex = 5;
            this.telefonTextBox.TextChanged += new System.EventHandler(this.telefonTextBox_TextChanged);
            // 
            // betreffLabel
            // 
            this.betreffLabel.AutoSize = true;
            this.betreffLabel.Font = new System.Drawing.Font("Microsoft Tai Le", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.betreffLabel.Location = new System.Drawing.Point(20, 178);
            this.betreffLabel.Name = "betreffLabel";
            this.betreffLabel.Size = new System.Drawing.Size(71, 23);
            this.betreffLabel.TabIndex = 6;
            this.betreffLabel.Text = "Betreff :";
            this.betreffLabel.Click += new System.EventHandler(this.betreffLabel_Click);
            // 
            // betreffTextBox
            // 
            this.betreffTextBox.Location = new System.Drawing.Point(180, 181);
            this.betreffTextBox.Name = "betreffTextBox";
            this.betreffTextBox.Size = new System.Drawing.Size(679, 22);
            this.betreffTextBox.TabIndex = 7;
            this.betreffTextBox.TextChanged += new System.EventHandler(this.betreffTextBox_TextChanged);
            // 
            // notizLabel
            // 
            this.notizLabel.AutoSize = true;
            this.notizLabel.Font = new System.Drawing.Font("Microsoft Tai Le", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.notizLabel.Location = new System.Drawing.Point(20, 233);
            this.notizLabel.Name = "notizLabel";
            this.notizLabel.Size = new System.Drawing.Size(61, 23);
            this.notizLabel.TabIndex = 8;
            this.notizLabel.Text = "Notiz :";
            // 
            // notizTextBox
            // 
            this.notizTextBox.Location = new System.Drawing.Point(180, 254);
            this.notizTextBox.Multiline = true;
            this.notizTextBox.Name = "notizTextBox";
            this.notizTextBox.Size = new System.Drawing.Size(679, 112);
            this.notizTextBox.TabIndex = 9;
            // 
            // notizComboBox
            // 
            this.notizComboBox.FormattingEnabled = true;
            this.notizComboBox.Items.AddRange(new object[] {
            "Termin vereinbart"});
            this.notizComboBox.Location = new System.Drawing.Point(180, 233);
            this.notizComboBox.Name = "notizComboBox";
            this.notizComboBox.Size = new System.Drawing.Size(550, 24);
            this.notizComboBox.TabIndex = 10;
            // 
            // anhangLabel
            // 
            this.anhangLabel.AutoSize = true;
            this.anhangLabel.Font = new System.Drawing.Font("Microsoft Tai Le", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.anhangLabel.Location = new System.Drawing.Point(20, 389);
            this.anhangLabel.Name = "anhangLabel";
            this.anhangLabel.Size = new System.Drawing.Size(81, 23);
            this.anhangLabel.TabIndex = 11;
            this.anhangLabel.Text = "Anhang :";
            this.anhangLabel.Click += new System.EventHandler(this.anhangLabel_Click);
            // 
            // filePathNameComboBox
            // 
            this.filePathNameComboBox.FormattingEnabled = true;
            this.filePathNameComboBox.Location = new System.Drawing.Point(180, 390);
            this.filePathNameComboBox.Name = "filePathNameComboBox";
            this.filePathNameComboBox.Size = new System.Drawing.Size(311, 24);
            this.filePathNameComboBox.TabIndex = 12;
            this.filePathNameComboBox.SelectedIndexChanged += new System.EventHandler(this.filePathNameComboBox_SelectedIndexChanged);
            // 
            // wiedervorlage
            // 
            this.wiedervorlage.AutoSize = true;
            this.wiedervorlage.Location = new System.Drawing.Point(24, 445);
            this.wiedervorlage.Name = "wiedervorlage";
            this.wiedervorlage.Size = new System.Drawing.Size(111, 20);
            this.wiedervorlage.TabIndex = 13;
            this.wiedervorlage.Text = "Widervorlage";
            this.wiedervorlage.UseVisualStyleBackColor = true;
            // 
            // screenshot
            // 
            this.screenshot.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.screenshot.Location = new System.Drawing.Point(752, 376);
            this.screenshot.Name = "screenshot";
            this.screenshot.Size = new System.Drawing.Size(107, 41);
            this.screenshot.TabIndex = 15;
            this.screenshot.Text = "Screenshot";
            this.screenshot.UseVisualStyleBackColor = false;
            this.screenshot.Click += new System.EventHandler(this.screenshot_Click);
            // 
            // kontaktAuswahlButton
            // 
            this.kontaktAuswahlButton.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.kontaktAuswahlButton.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kontaktAuswahlButton.Location = new System.Drawing.Point(737, 76);
            this.kontaktAuswahlButton.Name = "kontaktAuswahlButton";
            this.kontaktAuswahlButton.Size = new System.Drawing.Size(122, 57);
            this.kontaktAuswahlButton.TabIndex = 17;
            this.kontaktAuswahlButton.Text = "Kontakt \r\nAuswahl";
            this.kontaktAuswahlButton.UseVisualStyleBackColor = false;
            this.kontaktAuswahlButton.Click += new System.EventHandler(this.kontaktAuswahlButton_Click);
            // 
            // auswahlButton
            // 
            this.auswahlButton.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.auswahlButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.auswahlButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.auswahlButton.Location = new System.Drawing.Point(737, 141);
            this.auswahlButton.Name = "auswahlButton";
            this.auswahlButton.Size = new System.Drawing.Size(124, 34);
            this.auswahlButton.TabIndex = 18;
            this.auswahlButton.Text = "Auswahl";
            this.auswahlButton.UseVisualStyleBackColor = false;
            this.auswahlButton.Click += new System.EventHandler(this.auswahlButton_Click);
            // 
            // einfügenButton
            // 
            this.einfügenButton.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.einfügenButton.Location = new System.Drawing.Point(735, 209);
            this.einfügenButton.Name = "einfügenButton";
            this.einfügenButton.Size = new System.Drawing.Size(125, 45);
            this.einfügenButton.TabIndex = 19;
            this.einfügenButton.Text = "Einfügen";
            this.einfügenButton.UseVisualStyleBackColor = false;
            this.einfügenButton.Click += new System.EventHandler(this.einfügenButton_Click);
            // 
            // loadFileButton
            // 
            this.loadFileButton.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.loadFileButton.Location = new System.Drawing.Point(497, 372);
            this.loadFileButton.Name = "loadFileButton";
            this.loadFileButton.Size = new System.Drawing.Size(82, 48);
            this.loadFileButton.TabIndex = 20;
            this.loadFileButton.Text = "Datei hochladen";
            this.loadFileButton.UseVisualStyleBackColor = false;
            this.loadFileButton.Click += new System.EventHandler(this.loadFileButton_Click);
            // 
            // speichernButton
            // 
            this.speichernButton.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.speichernButton.Location = new System.Drawing.Point(24, 22);
            this.speichernButton.Name = "speichernButton";
            this.speichernButton.Size = new System.Drawing.Size(113, 37);
            this.speichernButton.TabIndex = 23;
            this.speichernButton.Text = "Speichern";
            this.speichernButton.UseVisualStyleBackColor = false;
            this.speichernButton.Click += new System.EventHandler(this.speichernButton_Click);
            // 
            // kontaktOffnenButton
            // 
            this.kontaktOffnenButton.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.kontaktOffnenButton.Location = new System.Drawing.Point(156, 22);
            this.kontaktOffnenButton.Name = "kontaktOffnenButton";
            this.kontaktOffnenButton.Size = new System.Drawing.Size(156, 37);
            this.kontaktOffnenButton.TabIndex = 24;
            this.kontaktOffnenButton.Text = "Kontakt Öffnen";
            this.kontaktOffnenButton.UseVisualStyleBackColor = false;
            this.kontaktOffnenButton.Click += new System.EventHandler(this.kontaktOffnenButton_Click);
            // 
            // historieButton
            // 
            this.historieButton.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.historieButton.Location = new System.Drawing.Point(338, 22);
            this.historieButton.Name = "historieButton";
            this.historieButton.Size = new System.Drawing.Size(113, 37);
            this.historieButton.TabIndex = 25;
            this.historieButton.Text = "Historie";
            this.historieButton.UseVisualStyleBackColor = false;
            this.historieButton.Click += new System.EventHandler(this.historieButton_Click);
            // 
            // druckenButton
            // 
            this.druckenButton.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.druckenButton.Location = new System.Drawing.Point(497, 22);
            this.druckenButton.Name = "druckenButton";
            this.druckenButton.Size = new System.Drawing.Size(113, 37);
            this.druckenButton.TabIndex = 26;
            this.druckenButton.Text = "Drucken";
            this.druckenButton.UseVisualStyleBackColor = false;
            this.druckenButton.Click += new System.EventHandler(this.druckenButton_Click);
            // 
            // funktionenButton
            // 
            this.funktionenButton.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.funktionenButton.Location = new System.Drawing.Point(653, 22);
            this.funktionenButton.Name = "funktionenButton";
            this.funktionenButton.Size = new System.Drawing.Size(113, 37);
            this.funktionenButton.TabIndex = 27;
            this.funktionenButton.Text = "Funktionen";
            this.funktionenButton.UseVisualStyleBackColor = false;
            // 
            // telefonNotiz
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(974, 542);
            this.Controls.Add(this.funktionenButton);
            this.Controls.Add(this.druckenButton);
            this.Controls.Add(this.historieButton);
            this.Controls.Add(this.kontaktOffnenButton);
            this.Controls.Add(this.speichernButton);
            this.Controls.Add(this.loadFileButton);
            this.Controls.Add(this.einfügenButton);
            this.Controls.Add(this.auswahlButton);
            this.Controls.Add(this.kontaktAuswahlButton);
            this.Controls.Add(this.screenshot);
            this.Controls.Add(this.wiedervorlage);
            this.Controls.Add(this.filePathNameComboBox);
            this.Controls.Add(this.anhangLabel);
            this.Controls.Add(this.notizComboBox);
            this.Controls.Add(this.notizTextBox);
            this.Controls.Add(this.notizLabel);
            this.Controls.Add(this.betreffTextBox);
            this.Controls.Add(this.betreffLabel);
            this.Controls.Add(this.telefonTextBox);
            this.Controls.Add(this.telefonLabel);
            this.Controls.Add(this.kontaktTextBox);
            this.Controls.Add(this.kontaktLabel);
            this.Controls.Add(this.firmennameTextBox);
            this.Controls.Add(this.firmennameLabel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "telefonNotiz";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Telefon Notiz";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label firmennameLabel;
        private System.Windows.Forms.Label kontaktLabel;
        private System.Windows.Forms.Label telefonLabel;
        private System.Windows.Forms.Label betreffLabel;
        private System.Windows.Forms.TextBox betreffTextBox;
        private System.Windows.Forms.Label notizLabel;
        private System.Windows.Forms.TextBox notizTextBox;
        private System.Windows.Forms.ComboBox notizComboBox;
        private System.Windows.Forms.Label anhangLabel;
        private System.Windows.Forms.ComboBox filePathNameComboBox;
        private System.Windows.Forms.CheckBox wiedervorlage;
        private System.Windows.Forms.Button screenshot;
        private System.Windows.Forms.Button kontaktAuswahlButton;
        private System.Windows.Forms.Button auswahlButton;
        private System.Windows.Forms.Button einfügenButton;
        private System.Windows.Forms.Button loadFileButton;
        private System.Windows.Forms.Button speichernButton;
        private System.Windows.Forms.Button kontaktOffnenButton;
        private System.Windows.Forms.Button historieButton;
        private System.Windows.Forms.Button druckenButton;
        private System.Windows.Forms.Button funktionenButton;
        public System.Windows.Forms.TextBox telefonTextBox;
        public System.Windows.Forms.TextBox firmennameTextBox;
        public System.Windows.Forms.TextBox kontaktTextBox;
    }
}

