﻿using System;
using System.Drawing;
using System.Drawing.Printing;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Drawing.Imaging;
using System.Net.Http;
using Newtonsoft.Json;
using System.Net.Http.Json;
using System.Collections.Generic;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Reflection.Emit;

namespace WindowsFormsApp1
{
    public partial class telefonNotiz : Form
    {
        private kontaktAuswahlForm kontaktAuswahlForm;
        private Historie historie;
        private kontaktOffnen kontaktOffnen;
        
        private static readonly HttpClient client = new HttpClient();

        public telefonNotiz()
        {
            InitializeComponent();
            kontaktAuswahlForm = kontaktAuswahlForm;
            historie = historie;
            kontaktOffnen = kontaktOffnen;
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void helloButton_Click(object sender, EventArgs e)
        {

        }

        private void firmennameLabel_Click(object sender, EventArgs e)
        {

        }

        private void firmennameTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void betreffLabel_Click(object sender, EventArgs e)
        {

        }

        private void telefonTextBox_TextChanged(object sender, EventArgs e)
        {
            

        }

        private void kontaktLabel_Click(object sender, EventArgs e)
        {

        }

        private void betreffTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void screenshot_Click(object sender, EventArgs e)
        {
            Bitmap bmp = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height);

            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.CopyFromScreen(0, 0, 0, 0, bmp.Size);
                
            }

           

        }
        private void anhangLabel_Click(object sender, EventArgs e)
        {

        }

        private void auswahlButton_Click(object sender, EventArgs e)
        {
           AuswahlForm auswahlForm = new AuswahlForm(this);
            auswahlForm.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void loadFileButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog dosyaSec = new OpenFileDialog();
            dosyaSec.Filter = "Dosya (*.*)|*.*";
            dosyaSec.Title = "Dosya Seç";
            dosyaSec.Multiselect = false;
            

            if (dosyaSec.ShowDialog() == DialogResult.OK)
            {
                string dosyaAdi = dosyaSec.SafeFileName;
                string dosyaYolu = dosyaSec.FileName;

                string filePathName = "Dateiname: " + dosyaAdi;

                // Dosya adını gösterin
                filePathNameComboBox.Items.Insert(0, filePathName);
                filePathNameComboBox.SelectedItem = filePathName;
            }
        }

        private void druckenButton_Click(object sender, EventArgs e)
        {
            PrintDocument pd = new PrintDocument();
            pd.PrintPage += new PrintPageEventHandler(PrintImage);
            PrintPreviewDialog ppd = new PrintPreviewDialog();
            ppd.Document = pd;
            ppd.ShowDialog();
        }

        private void PrintImage(object sender, PrintPageEventArgs e)
        {
            Bitmap bmp = new Bitmap(this.Width, this.Height);
            this.DrawToBitmap(bmp, new Rectangle(0, 0, this.Width, this.Height));
            e.Graphics.DrawImage(bmp, 0, 0);
        }

        private void historieButton_Click(object sender, EventArgs e)
        {
            historie = new Historie();
            historie.Show();
        }

        private async void speichernButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Prepare the data for the POST request
                var data = new
                {
                    customerName = firmennameTextBox.Text,
                    kontakt = kontaktTextBox.Text,
                    telNumber = telefonTextBox.Text,
                    topic = betreffTextBox.Text,
                    note = notizTextBox.Text,
                    file_path = filePathNameComboBox.Text
                };


                // Send the POST request
                if (data.customerName == "" || data.kontakt == "" || data.telNumber == "" || data.topic == "" || data.note == "")
                {
                    string errorMessage = "Please fill all the fields except Anhang.";
                    MessageBox.Show(errorMessage, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                var response = await client.PostAsJsonAsync("http://127.0.0.1:5000/api/v1/users-post", data);

                // Check the response status
                if (response.IsSuccessStatusCode)
                {
                    string successMessage = "User added successfully.";
                    MessageBox.Show(successMessage, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    firmennameTextBox.Text = "";
                    kontaktTextBox.Text = "";
                    telefonTextBox.Text = "";
                    betreffTextBox.Text = "";
                    notizTextBox.Text = "";
                    filePathNameComboBox.Text = "";
                }
                else
                {
                    string failMessage = "Failed to add user. Status code: " + response.StatusCode;
                    MessageBox.Show(failMessage, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                string errorMessage = "An error occurred: " + ex.Message;
                MessageBox.Show(errorMessage, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void filePathNameComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void folderBrowserDialog1_HelpRequest(object sender, EventArgs e)
        {

        }

        private void einfügenButton_Click(object sender, EventArgs e)
        {
            notizTextBox.Text = notizComboBox.Text;
        }

        private void kontaktAuswahlButton_Click(object sender, EventArgs e)
        {
            kontaktAuswahlForm = new kontaktAuswahlForm(this);
            kontaktAuswahlForm.Show();

        }

        private void kontaktOffnenButton_Click(object sender, EventArgs e)
        {
            kontaktOffnen = new kontaktOffnen();
            kontaktOffnen.Show();
        }
    }


    
}
